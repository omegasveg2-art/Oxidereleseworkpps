// Oxide: Survival Island state reader (read-only): local camera + every PlayerManager the client knows.
#pragma once
#include "il2cpp.h"
#include "vmath.h"
#include <map>
#include <string>
#include <vector>

struct OxPlayer {
    uint32_t id = 0;
    Vec3 pos, vel;
    bool local = false, dead = false;
    int hp = 100;
    char name[32] = {0};
};

struct OxSnap {
    Cam cam;
    std::vector<OxPlayer> players;
};

class OxGame {
public:
    OxGame(IMem& m, uint64_t il2cppBase) : m_(m), il_(m, il2cppBase) {}
    bool update(OxSnap& s, float fovY);          // false -> status() says why
    const char* status() const { return status_.c_str(); }
    std::string diag() const { return diag_; }
    int classes_seen() const { return il_.classes_seen(); }
    // Unity native Transform chain of a managed Component: world position + rotation (x,y,z,w); validated by the caller
    bool comp_trs(uint64_t component, Vec3& pos, float q[4]);
private:
    bool nat_trs(uint64_t nativeTransform, Vec3& pos, float q[4]);
    static constexpr int NC = 6;
    int pos_cands(uint64_t pm, Vec3 out[NC], bool ok[NC], uint64_t* kccOut);
    std::string nick(uint64_t pm);
    struct CS { Vec3 last[6]; double t[6] = {0, 0, 0, 0, 0, 0}, chg[6] = {0, 0, 0, 0, 0, 0}; int sel = -1; };
    std::map<uint64_t, CS> cs_;
    uint64_t kccCache_ = 0;
    bool read_hp(uint64_t vitals, int& hp, std::string& name);
    IMem& m_;
    Il2 il_;
    uint64_t kPM_ = 0, pmStatics_ = 0;
    std::string status_ = "init", diag_;
    struct Track { Vec3 pos; double t = 0; Vec3 vel; };
    std::map<uint64_t, Track> tr_;
    std::vector<uint64_t> heap_;
    double nextScan_ = 0;
};
