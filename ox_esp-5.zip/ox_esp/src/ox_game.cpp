#include "ox_game.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>

static double now_s() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
static bool fin3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

// Hamilton product a*b, quaternions as (x,y,z,w)
static void qmul(const float a[4], const float b[4], float o[4]) {
    o[0] = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1];
    o[1] = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0];
    o[2] = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3];
    o[3] = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2];
}
static Vec3 qrot(const float q[4], Vec3 v) {
    Vec3 u{q[0], q[1], q[2]};
    Vec3 t = cross(u, v) * 2.f;
    return v + t * q[3] + cross(u, t);
}

// Unity 2019-2022 (64-bit) native Transform -> TransformHierarchy: +0x38 hierarchy, +0x40 index; hierarchy +0x18 = TRS[48 bytes: pos, pad, rot(xyzw), scale], +0x20 = parent indices
bool OxGame::nat_trs(uint64_t nat, Vec3& pos, float q[4]) {
    if (!plausible_ptr(nat)) return false;
    uint64_t hier = rdp(m_, nat + 0x38);
    int idx = (int)rd32(m_, nat + 0x40);
    if (!plausible_ptr(hier) || idx < 0 || idx > 200000) return false;
    uint64_t list = rdp(m_, hier + 0x18), par = rdp(m_, hier + 0x20);
    if (!plausible_ptr(list) || !plausible_ptr(par)) return false;
    float t[12];
    if (!m_.read(list + 0x30ull * (uint64_t)idx, t, sizeof t)) return false;
    Vec3 r{t[0], t[1], t[2]};
    float wq[4] = {t[4], t[5], t[6], t[7]};
    int cur = (int)rd32(m_, par + 4ull * (uint64_t)idx);
    for (int g = 0; cur >= 0 && g < 64; g++) {
        if (cur > 200000 || !m_.read(list + 0x30ull * (uint64_t)cur, t, sizeof t)) return false;
        float pq[4] = {t[4], t[5], t[6], t[7]};
        Vec3 sv{r.x * t[8], r.y * t[9], r.z * t[10]};
        r = Vec3{t[0], t[1], t[2]} + qrot(pq, sv);
        float nq[4];
        qmul(pq, wq, nq);
        memcpy(wq, nq, sizeof nq);
        cur = (int)rd32(m_, par + 4ull * (uint64_t)cur);
    }
    if (!fin3(r)) return false;
    float n = std::sqrt(wq[0] * wq[0] + wq[1] * wq[1] + wq[2] * wq[2] + wq[3] * wq[3]);
    if (!(n > 0.9f && n < 1.1f)) return false;
    pos = r;
    for (int i = 0; i < 4; i++) q[i] = wq[i] / n;
    return true;
}

bool OxGame::comp_trs(uint64_t comp, Vec3& pos, float q[4]) {
    uint64_t nat = rdp(m_, comp + 0x10);                 // UnityEngine.Object.m_CachedPtr
    if (!plausible_ptr(nat)) return false;
    uint64_t go = rdp(m_, nat + 0x30);                   // Component.m_GameObject
    if (!plausible_ptr(go)) return false;
    uint64_t arr = rdp(m_, go + 0x30);                   // GameObject components {typeIndex, Component*}; Transform first
    if (!plausible_ptr(arr)) return false;
    return nat_trs(rdp(m_, arr + 0x8), pos, q);
}

// Vitals -> Entity (kAH) -> Health (reactive float: value after two pointers) ; DisplayName string.
bool OxGame::read_hp(uint64_t vitals, int& hp, std::string& name) {
    if (!plausible_ptr(vitals)) return false;
    uint64_t ent = rdp(m_, vitals + off::Vitals::Entity);
    if (!plausible_ptr(ent)) return false;
    name = il_.str(rdp(m_, ent + off::Vitals::E_DisplayName), 24);
    uint64_t hv = rdp(m_, ent + off::Vitals::E_Health);
    float mx = rdf(m_, vitals + off::Vitals::m_MaxHealth);
    if (!std::isfinite(mx) || mx < 1.f || mx > 100000.f) mx = 100.f;
    if (!plausible_ptr(hv)) return false;
    float a = rdf(m_, hv + 0x20), b = rdf(m_, hv + 0x24);
    float h = -1.f;
    if (std::isfinite(a) && a >= 0.f && a <= mx * 1.05f) h = a;
    else if (std::isfinite(b) && b >= 0.f && b <= mx * 1.05f) h = b;
    if (h < 0.f) return false;
    hp = (int)std::lround(h / mx * 100.f);
    return true;
}

// Managed-only positions (no Unity native structures: Unity 6 changed them). Several fields can carry a player's position; which one is LIVE for remote
// players is not known from the dump, so all are sampled and the one that actually changes is used (per player, with hysteresis).
static bool good_pos(Vec3 v) { return fin3(v) && (std::fabs(v.x) + std::fabs(v.y) + std::fabs(v.z)) > 0.01f && std::fabs(v.x) < 1e5f && std::fabs(v.y) < 1e5f && std::fabs(v.z) < 1e5f; }

int OxGame::pos_cands(uint64_t pm, Vec3 out[NC], bool ok[NC], uint64_t* kccOut) {
    for (int i = 0; i < NC; i++) ok[i] = false;
    uint64_t kcc = 0, motor = 0;
    uint64_t ref = rdp(m_, pm + 0xB0);                         // InterfaceReference<Yc> (class): _component at +0x10
    if (plausible_ptr(ref)) {
        kcc = rdp(m_, ref + 0x10);
        if (plausible_ptr(kcc)) {
            if (kcc != kccCache_) {
                if (il_.cstr(rdp(m_, rdp(m_, kcc) + il2::K_NAME)) == "KCC") kccCache_ = kcc; else kcc = 0;
            }
        } else kcc = 0;
    }
    if (kcc) {
        motor = rdp(m_, kcc + 0x68);
        out[2] = rdv<Vec3>(m_, kcc + 0xF0 + 0xC);              // KCC Move (last simulated/applied).Position
        out[3] = rdv<Vec3>(m_, kcc + 0x1AC + 0xC);             // KCC second Move.Position
        ok[2] = good_pos(out[2]); ok[3] = good_pos(out[3]);
        if (plausible_ptr(motor)) {
            out[0] = rdv<Vec3>(m_, motor + 0x1EC);             // KinematicCharacterMotor.LastInterpolatedPosition
            out[1] = rdv<Vec3>(m_, motor + 0x1E0);             // InitialTickPosition
            ok[0] = good_pos(out[0]); ok[1] = good_pos(out[1]);
        }
    }
    out[4] = rdv<Vec3>(m_, pm + 0x1E8); ok[4] = good_pos(out[4]);   // PlayerManager.lastTickPosition
    out[5] = rdv<Vec3>(m_, pm + 0x1F4); ok[5] = good_pos(out[5]);   // lastSavedPosition
    if (kccOut) *kccOut = kcc;
    int n = 0;
    for (int i = 0; i < NC; i++) n += ok[i];
    return n;
}

std::string OxGame::nick(uint64_t pm) {
    uint64_t di = rdp(m_, pm + 0x130);                         // nicklabel (Di) -> nickname (UI Text) -> m_Text
    if (!plausible_ptr(di)) return {};
    uint64_t tx = rdp(m_, di + 0x38);
    if (!plausible_ptr(tx)) return {};
    return il_.str(rdp(m_, tx + 0xE0), 24);
}

bool OxGame::update(OxSnap& s, float fovY) {
    s.players.clear();
    if (!kPM_) kPM_ = il_.klass(off::PlayerManager::cls);
    if (!kPM_) { status_ = "no PlayerManager class (classes seen " + std::to_string(il_.classes_seen()) + ")"; return false; }
    if (!pmStatics_) pmStatics_ = il_.statics(kPM_);
    if (!pmStatics_) { status_ = "PlayerManager statics null"; return false; }
    // players: the static client list first; when it is empty fall back to a heap scan for PlayerManager objects
    std::vector<uint64_t> ptrs;
    uint64_t items; uint32_t n = 0;
    const char* src = "list";
    if (il_.list(rdp(m_, pmStatics_ + off::PlayerManager::s_clientPlayerList), items, n, 512) && n > 0) {
        uint64_t raw[512] = {0};
        if (m_.read(items + il2::ARR_DATA, raw, n * 8)) for (uint32_t i = 0; i < n; i++) ptrs.push_back(untag(raw[i]));
    }
    if (ptrs.empty()) {
        src = "scan";
        const double t0 = now_s();
        if (t0 >= nextScan_ || heap_.empty()) {
            nextScan_ = t0 + 2.0;
            heap_ = il_.find_instances(kPM_, [&](uint64_t o) { return rdp(m_, o) == kPM_ && plausible_ptr(rdp(m_, o + off::PlayerManager::netIdentity)); });
        }
        ptrs = heap_;
    }
    if (ptrs.empty()) { status_ = "no players yet (join a match)"; return false; }
    n = (uint32_t)ptrs.size();

    const double t = now_s();
    uint64_t localObj = 0, localKcc = 0;
    int nameOk = 0, hpOk = 0, posOk = 0, nLp = 0, nOwn = 0, nFp = 0;
    uint64_t ownObj = 0, fpObj = 0;
    bool firstRemote = false; char selDiag[64] = "src=?";
    struct Row { uint64_t o; uint64_t kcc; OxPlayer p; };
    std::vector<Row> rows;
    for (uint32_t i = 0; i < n; i++) {
        uint64_t o = ptrs[i];
        if (!plausible_ptr(o) || rdp(m_, o) != kPM_) continue;
        OxPlayer p;
        uint64_t ni = rdp(m_, o + off::PlayerManager::netIdentity);
        if (plausible_ptr(ni)) {
            p.id = rd32(m_, ni + 0x58);
            p.local = rd8(m_, ni + off::NetworkIdentity::isLocalPlayer) != 0;
            if (p.local) nLp++;
            if (rd8(m_, ni + 0x4B) != 0) { nOwn++; if (!ownObj) ownObj = o; }       // isOwned
        }
        {
            uint64_t fpm = rdp(m_, o + off::PlayerManager::fpManager);
            if (plausible_ptr(fpm) && plausible_ptr(rdp(m_, fpm + off::FPManager::m_WorldCamera))) { nFp++; if (!fpObj) fpObj = o; }
        }
        if (!p.id) p.id = (uint32_t)(o >> 4);
        Vec3 cv[NC]; bool cok[NC]; uint64_t kcc = 0;
        Vec3 pos;
        if (pos_cands(o, cv, cok, &kcc) > 0) {
            auto& st = cs_[o];
            int best = -1; double bestT = -1;
            for (int c = 0; c < NC; c++) {
                if (!cok[c]) continue;
                if (st.t[c] == 0) { st.last[c] = cv[c]; st.t[c] = t; st.chg[c] = 0; continue; }
                if (len(cv[c] - st.last[c]) > 0.02f) { st.last[c] = cv[c]; st.chg[c] = t; }
                if (st.chg[c] > bestT) { bestT = st.chg[c]; best = c; }
            }
            if (best >= 0 && bestT > 0 && (st.sel < 0 || !cok[st.sel] || bestT > st.chg[st.sel] + 0.05)) st.sel = best;
            if (st.sel < 0 || !cok[st.sel]) { st.sel = -1; for (int c = 0; c < NC; c++) if (cok[c]) { st.sel = c; break; } }
            if (st.sel < 0) continue;
            pos = cv[st.sel];
            if (!p.local && !firstRemote) { firstRemote = true; char d[16]; int m = 0; for (int c = 0; c < NC; c++) d[m++] = (!cok[c]) ? '-' : (t - st.chg[c] < 2.0 && st.chg[c] > 0) ? '1' : '0'; d[m] = 0; snprintf(selDiag, sizeof selDiag, "src=%d ch=%s", st.sel, d); }
        } else {
            float q[4];
            if (!comp_trs(o, pos, q)) continue;                  // native chain: only a fallback
        }
        posOk++;
        p.pos = pos;
        int hp = 100; std::string nm;
        if (read_hp(rdp(m_, o + off::PlayerManager::vitals), hp, nm)) { p.hp = hp; hpOk++; }
        p.dead = p.hp <= 0;
        if (nm.empty()) nm = nick(o);
        if (!nm.empty()) { snprintf(p.name, sizeof p.name, "%s", nm.c_str()); nameOk++; }
        auto& tk = tr_[o];
        if (tk.t > 0 && t - tk.t > 0.02 && t - tk.t < 0.5) {
            Vec3 v = (pos - tk.pos) * (float)(1.0 / (t - tk.t));
            tk.vel = tk.vel * 0.6f + v * 0.4f;
            tk.pos = pos; tk.t = t;
        } else if (tk.t == 0 || t - tk.t >= 0.5) { tk.pos = pos; tk.t = t; tk.vel = Vec3{}; }
        p.vel = tk.vel;
        rows.push_back({o, kcc, p});
    }
    // local = isLocalPlayer, else isOwned, else the one with a first-person camera
    for (auto& r : rows) if (r.p.local) { localObj = r.o; localKcc = r.kcc; break; }
    if (!localObj) for (auto& r : rows) if (r.o == ownObj) { localObj = r.o; localKcc = r.kcc; r.p.local = true; break; }
    if (!localObj) for (auto& r : rows) if (r.o == fpObj) { localObj = r.o; localKcc = r.kcc; r.p.local = true; break; }
    for (auto& r : rows) s.players.push_back(r.p);
    if (!localObj) {
        char e[140];
        snprintf(e, sizeof e, "local player not found (pm=%u pos=%d lp=%d own=%d fp=%d)", n, posOk, nLp, nOwn, nFp);
        status_ = e;
        return false;
    }
    Vec3 feet;
    for (auto& pl : s.players) if (pl.local) feet = pl.pos;

    // camera. 1) the native world camera when the Transform chain validates and sits at the player's head; 2) managed: eye = feet + height,
    // direction = KCC's last PlayerInput.LookDirection (bWJ at 0x184 + 8), else yaw from the motor + pitch from PlayerManager.lookAngle
    const char* camSrc = "none";
    Vec3 cp, fw{0, 0, 1}; bool have = false;
    {
        uint64_t fp = rdp(m_, localObj + off::PlayerManager::fpManager);
        uint64_t cam = plausible_ptr(fp) ? rdp(m_, fp + off::FPManager::m_WorldCamera) : 0;
        float q[4]; Vec3 np;
        if (plausible_ptr(cam) && comp_trs(cam, np, q) && len(np - feet) < 2.6f && np.y - feet.y > 0.3f) {
            cp = np; fw = norm(qrot(q, Vec3{0, 0, 1})); have = true; camSrc = "native";
        }
    }
    if (!have && localKcc) {
        Vec3 look = rdv<Vec3>(m_, localKcc + 0x184 + 0x8);
        float ll = fin3(look) ? len(look) : 0.f;
        float eye = 1.62f;
        if (ll > 0.95f && ll < 1.05f) { fw = norm(look); camSrc = "kcc-look"; }
        else {
            float yaw = rdf(m_, localKcc + 0x184 + 0x14);       // PlayerInput.YRotation (degrees)
            float pit = rdf(m_, localObj + 0x1C8);              // PlayerManager.lookAngle
            if (std::isfinite(yaw) && std::isfinite(pit) && std::fabs(pit) < 91.f) {
                float yr = yaw * 3.14159265f / 180.f, pr = pit * 3.14159265f / 180.f;
                fw = norm(Vec3{std::sin(yr) * std::cos(pr), -std::sin(pr), std::cos(yr) * std::cos(pr)});
                camSrc = "yaw+pitch";
            } else { status_ = "camera not readable (no look vector)"; return false; }
        }
        cp = feet + Vec3{0, eye, 0};
        have = true;
    }
    if (!have) { status_ = "camera not readable (no KCC)"; return false; }
    s.cam.pos = cp; s.cam.fwd = fw; s.cam.fovY = fovY;
    char b[200];
    snprintf(b, sizeof b, "pm=%u/%s pos=%d hp=%d nm=%d lp=%d own=%d fp=%d cam=%s %s", n, src, posOk, hpOk, nameOk, nLp, nOwn, nFp, camSrc, selDiag);
    diag_ = b;
    status_ = "ok";
    return true;
}
